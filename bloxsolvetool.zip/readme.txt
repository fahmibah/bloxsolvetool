========================================================================
             TUTORIAL PENGGUNAAN COOKIE RUNNER / BLOCKSOLVE TOOL
========================================================================

Cookie Runner (BlockSolve Tool) adalah tool CLI/TUI berbasis terminal untuk 
melakukan pengecekan status Roblox Cookie (.ROBLOSECURITY) secara massal 
dan menyelesaikan tantangan captcha (Arkose Labs) secara otomatis.

------------------------------------------------------------------------
ISI PAKET DATA / PACKAGE CONTENTS
------------------------------------------------------------------------
1. blocksolvetool.exe : File executable utama (dikompilasi menggunakan Nuitka).
2. config.json        : File konfigurasi server solver, API key, dan delay.
3. cookies.txt        : File input untuk menaruh daftar Roblox Cookie Anda.
4. readme.txt         : Panduan instruksi ini.

------------------------------------------------------------------------
PANDUAN - BAHASA INDONESIA
------------------------------------------------------------------------

Langkah 1: Konfigurasi API Key & URL (WAJIB)
1. Buka file "config.json" menggunakan Notepad atau editor teks lainnya.
2. Masukkan API Key Anda di bagian `"api_key"`.
3. Pastikan kolom `"url"` terisi dengan: "https://blocksolve.site/join" (WAJIB).
   Contoh konfigurasi yang benar:
   "solver": {
       "url": "https://blocksolve.site/join",
       "api_key": "MASUKKAN_API_KEY_ANDA_DI_SINI"
   }
4. Jika ingin mengubah ID Game target (Place ID) untuk test join, ubah bagian `"place_id"`.
5. Simpan file "config.json".

Langkah 2: Menyiapkan Daftar Cookie (.ROBLOSECURITY)
1. Buka file "cookies.txt".
2. Masukkan daftar Cookie Anda di file ini (satu baris satu cookie).
3. Format yang didukung:
   - Baris cookie mentah (Dimulai dengan _|WARNING:-...)
   - Format Username:Password:Cookie (Tool akan otomatis mengekstrak cookie-nya saja).
4. Simpan file "cookies.txt".

Langkah 3: Menjalankan Tool
1. Double-click file "blocksolvetool.exe" untuk menjalankannya.


========================================================================
             COOKIE RUNNER / BLOCKSOLVE TOOL - USER MANUAL
========================================================================

Cookie Runner (BlockSolve Tool) is a terminal-based CLI/TUI utility designed
to check the status of Roblox Cookies (.ROBLOSECURITY) in bulk and solve
captcha challenges (Arkose Labs) automatically.

------------------------------------------------------------------------
INSTRUCTIONS - ENGLISH
------------------------------------------------------------------------

Step 1: Configure API Key & URL (REQUIRED)
1. Open the "config.json" file using Notepad or any text editor.
2. Insert your API Key in the `"api_key"` field.
3. Make sure the `"url"` field is set to: "https://blocksolve.site/join" (REQUIRED).
   Example of a correct configuration:
   "solver": {
       "url": "https://blocksolve.site/join",
       "api_key": "YOUR_API_KEY_HERE"
   }
4. If you want to change the target game (Place ID) for the join test, edit the `"place_id"` field.
5. Save the "config.json" file.

Step 2: Preparing the Cookie List (.ROBLOSECURITY)
1. Open the "cookies.txt" file.
2. Paste your Roblox cookies here (one cookie per line).
3. Supported formats:
   - Raw cookie value (Starts with _|WARNING:-...)
   - Username:Password:Cookie format (The tool will automatically parse out the cookie value).
4. Save the "cookies.txt" file.

Step 3: Running the Tool
1. Double-click "blocksolvetool.exe" to run the tool.

------------------------------------------------------------------------
PENANGANAN OUTPUT / OUTPUT HANDLING (Bilingual)
------------------------------------------------------------------------
Setelah dijalankan, tool secara otomatis memisahkan status cookie / 
The tool automatically separates checked cookies into two files:
- alive_cookies.txt : Cookie aktif & lolos captcha / Active & passed cookies.
- dead_cookies.txt  : Cookie mati atau invalid / Expired or invalid cookies.

Catatan / Note:
Jika server penuh (HTTP 503), tool akan menunggu 15 detik sebelum retry / 
If the server is busy (HTTP 503), the tool waits 15 seconds before retrying.
