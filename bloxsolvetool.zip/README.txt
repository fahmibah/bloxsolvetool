========================================================================
             ROBLOX COOKIE RUNNER & CAPTCHA SOLVER PORT
========================================================================

CookieRunner is a premium command-line utility designed to check Roblox
cookies, perform direct quick validation, solve joining verification
captchas via your custom solver service domain, remove dead cookies,
and iterate indefinitely (similar to WinterTool).

------------------------------------------------------------------------
FILES IN THIS PACKAGE
------------------------------------------------------------------------
1. CookieRunner.exe  - The standalone Compiled Executable.
2. config.json       - The configuration file for settings.
3. README.txt        - This help document.

------------------------------------------------------------------------
CONFIGURATION OPTIONS (config.json)
------------------------------------------------------------------------
Open `config.json` in any text editor to adjust your settings:

* "runtime"
  - "loop":             true/false to loop indefinitely after checking all cookies.
  - "delay_minutes":    Cooldown time (in minutes) between each loop cycle.
  - "delay_per_cookie": Delay (in seconds) between handling each cookie.
  - "max_workers":      Maximum number of simultaneous active solver workers.

* "solver"
  - "url":              The endpoint URL of your solver service.
                        (e.g., "https://blocksolve.site/join")
  - "api_key":          Your authorization API key for blocksolve.

* "target"
  - "place_id":         The target Roblox Place ID to join.

* "files"
  - "cookies_file":        Path to the text file containing Roblox cookies.
  - "alive_cookies_file":  Path to save valid and solved cookies.
  - "dead_cookies_file":   Path to save invalidated cookies.

------------------------------------------------------------------------
HOW TO RUN
------------------------------------------------------------------------
1. Make sure your Roblox cookies are added to your cookies file.
   (One cookie per line; starts with "_|WARNING:-DO-NOT-SHARE-THIS...")
2. Place 'CookieRunner.exe' and 'config.json' in the same folder.
3. Configure the 'config.json' with your blocksolve domain API key.
4. Run 'CookieRunner.exe' by double-clicking or launching it from
   the terminal/command prompt.
